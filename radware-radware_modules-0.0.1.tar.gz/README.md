<img src="https://www.radware.com/RadwareSite/MediaLibraries/Images/logo.svg" width="300px">

# radware-ansible

# Requirements
- Ansible >= 2.9
- Python >= 3.6

# Installing the Build
```
# ansible-galaxy collection install <collection name>
# e.g.
# ansible-galaxy collection install radware-radware_modules-1.0.0.tar.gz
```
